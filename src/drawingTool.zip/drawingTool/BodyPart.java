package drawingTool;

public class BodyPart {
    private int width;
    private int height;

    BodyPart(int width, int height) {
        this.width = width;
        this.height = height;
    }

    void drawAt(int left, int bottom) {
   
    }
    public  int getWidth(){
    	return width;
    }
    public  int getHeight(){
    	return height;
    }
    
}
